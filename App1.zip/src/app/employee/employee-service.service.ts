import { Injectable } from '@angular/core';
import { Employee } from './employee-display/employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService {
  employee:Employee[] = [{id:101,name:'satish',salary:10000,dept:'Hr'}];
  constructor() { }
  getEmployee()
  {
    return this.employee;
  }
}
