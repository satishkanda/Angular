import { Component, OnInit } from '@angular/core';
import { Employee } from './employee';
import { EmployeeServiceService } from '../employee-service.service';

@Component({
  selector: 'app-employee-display',
  templateUrl: './employee-display.component.html',
  styleUrls: ['./employee-display.component.css']
})
export class EmployeeDisplayComponent implements OnInit {
  employee: Employee[];
  constructor(private employeeService: EmployeeServiceService) { }

  ngOnInit() {
  }
  get(value) {
    if (this.employee[]) {
      alert("Value Already present");
    }
    else {

      this.employeeService.getEmployee().push(value);
    }
  }
}
