import { Component, OnInit } from '@angular/core';
import { Employee } from './employee/employee-display/employee';
import { EmployeeServiceService } from './employee/employee-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  employee: Employee[];
  constructor(private employeeService: EmployeeServiceService) { }
  ngOnInit() {

    this.employee = this.employeeService.getEmployee();
  }

}
