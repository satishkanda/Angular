import { Injectable } from '@angular/core';
import { Transaction } from './Transaction';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BankService {
  accounts: Account[];
  transactions: Transaction;


  constructor(private http: HttpClient) {
    
  }
  populateAccounts(): Observable<Account[]> {
    return this.http.get<Account[]>("http://localhost:4002/accounts");

  }
  getAccounts():Observable<Account[]>{
    return this.http.get<Account[]>("http://localhost:4002/accounts");
  }
  addAccount(account: Account) {
  return this.http.post<Account>("http://localhost:4002/create",account).toPromise().then(data => console.log(data));

  }
}
