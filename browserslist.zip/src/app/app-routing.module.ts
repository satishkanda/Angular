import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateAccountComponent } from './bank/create-account/create-account.component';
import { HomeComponent } from './bank/home/home.component';
import { ShowAccountsComponent } from './bank/show-accounts/show-accounts.component';
import { OperationsComponent } from './bank/operations/operations.component';



const routes: Routes = [
  { path:"create",component:CreateAccountComponent},
  { path:"show",component:ShowAccountsComponent},
  { path:"action",component:OperationsComponent},

  {path:'',component:HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
