package com.cg.emp.service;

import java.util.List;

import com.cg.emp.beans.Employee;
import com.cg.emp.exception.EmployeeException;

public interface EmployeeService {
	List<Employee> getAllEmployees() throws EmployeeException;
}
