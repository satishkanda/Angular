import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeListComponent } from './employee/employee-list.component';
import { AddEmployeeComponent } from './employee/add-employee.component';
import { HomeComponent } from './employee/home.component';
import { EmployeeComponent } from './employee/employee/employee.component';
import { SearchEmployeeComponent } from './employee/search-employee/search-employee.component';
import { AddEmployeeCanDeativateRouterGuardService } from './employee/add-employee-can-deativate-router-guard.service';


const routes: Routes = [
  { path:"employees",component:EmployeeListComponent},
  {path:"add",component:AddEmployeeComponent,canDeactivate:[AddEmployeeCanDeativateRouterGuardService]},
  {path:"employees/:id",component:EmployeeComponent},
  {path:"search",component:SearchEmployeeComponent},
  {path:'',component:HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
