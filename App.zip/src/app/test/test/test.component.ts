import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
 name="Personal Details";
 employee=[{
   firstname:"satish",
   lastname:"Kanda",
   gender:"male",
   age:21
 },{
  firstname:"Akhil",
  lastname:"govind",
  gender:"male",
  age:21
}]
showDetails:boolean=false;
toggleDetails(){
  this.showDetails=!this.showDetails;
}
Add(){
  var n1=parseInt((document.getElementById("n1") as HTMLInputElement).value);
  var n2=parseInt((document.getElementById("n2") as HTMLInputElement).value);
  var res=n1+n2;
  document.getElementById("result").innerHTML="result is:"+res;
}
clear()
{
  (document.getElementById("n1")as HTMLInputElement).value="";
  (document.getElementById("n2")as HTMLInputElement).value="";
  document.getElementById("result").innerHTML="";
}
  constructor() { }

  ngOnInit() {
  }

}
