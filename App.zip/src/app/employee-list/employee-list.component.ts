import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee/employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css'],
  providers:[EmployeeService]
})
export class EmployeeListComponent implements OnInit {
  searchTerm:string;
 selectedRadioButtonValue:string="all";
  employee;
  constructor(private employeeService:EmployeeService) {}

  ngOnInit() {
    this.employee=this.employeeService.getEmployees();
      }
      getAllEmployeesCount():number{
        return this.employee.length;
      }
      getMaleEmployeeCount(){
        return this.employee.filter(e=>e.gender==="Male").length;
      }
      getFemaleEmployeeCount(){
        return this.employee.filter(e=>e.gender==="Female").length;
      }

      onRadioButtonValueChange(value:string)
      {

        console.log(value);
        this.selectedRadioButtonValue=value;
      }
}
