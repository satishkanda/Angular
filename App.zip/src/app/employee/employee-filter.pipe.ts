import { Pipe, PipeTransform } from '@angular/core';
//import { EmployeeListComponent } from '../employee-list/employee-list.component';

@Pipe({
  name: 'employeeFilter'
})
export class EmployeeFilterPipe implements PipeTransform {

  transform(employee:any[],searchTerm:string):any[] {
    if(!employee||!searchTerm){
      return employee;
    }
    return employee.filter(emp=>emp.name.toLowerCase().indexOf(searchTerm.toLowerCase())!=-1);
  }

}
