import { Directive, HostListener, ElementRef, Renderer, HostBinding } from '@angular/core';

@Directive({
  selector: '[appDemo]'
})
export class DemoDirective {
  @HostBinding('style.font-size')
  fontSize:string;
 @HostListener('click')
onclick()
{
 this.renderer.setElementStyle(this.el.nativeElement,'color','blue');
 this.renderer.setElementStyle(this.el.nativeElement,'border','3px solid red');
 this.fontSize="5mm";
}
@HostListener('dblclick')
ondblclick(){
  this.renderer.setElementStyle(this.el.nativeElement,'color','blue');
  this.renderer.setElementStyle(this.el.nativeElement,'border','none');
  this.fontSize="10mm";
}
  constructor(private el:ElementRef,private renderer:Renderer) { }

}
