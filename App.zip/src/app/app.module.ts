import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TestComponent } from './test/test/test.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmployeeCountComponent} from './employee/employee-count.component';
import { ChangeCaseDirective } from './change-case.directive';
import { ColorDirectiveDirective } from './color-directive.directive';
import { DemoDirective } from './demo.directive';
import { EmployeeTitlePipe } from './employee/employee-title.pipe';
import { EmployeeFilterPipe } from './employee/employee-filter.pipe';

@NgModule({
  declarations: [
    AppComponent,
    TestComponent,
    EmployeeListComponent,
   EmployeeCountComponent,
   ChangeCaseDirective,
   ColorDirectiveDirective,
   DemoDirective,
   EmployeeTitlePipe,
   EmployeeFilterPipe,
   

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
