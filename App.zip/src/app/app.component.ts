import { Component, Input ,OnInit } from '@angular/core';
import { getLocaleDayNames } from '@angular/common';
import { FormGroup,FormControl,Validator, Validators,FormBuilder} from '@angular/forms'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  // userForm:FormGroup=new FormGroup({
  //   name: new FormControl(null,[Validators.required,Validators.minLength(4),Validators.maxLength(12)]),
  //   email: new FormControl(null,Validators.required),
  //   address: new FormGroup({
  //   street: new FormControl(null,Validators.required),
  //   city: new FormControl(null,Validators.required),
  //   pincode: new FormControl(null,[Validators.pattern("[1-9][0-9]{5}"),Validators.required])
  //  })
  //  });
  userForm:FormGroup;
  title = 'India';
  day:number;
  constructor(private formBuilder:FormBuilder){

  }
  ngOnInit() {
    this.userForm=this.formBuilder.group({
      name:[null,[Validators.required,Validators.minLength(4),Validators.maxLength(12)]],
      email:[null,Validators.required,],
      address:this.formBuilder.group({
        street:[null,Validators.required],
        city:[null,Validators.required],
        pincode:[null,[Validators.pattern("[1-9][0-9]{5}"),Validators.required]]
      })


    })  }
  getDay()
  {
     this.day=parseInt((document.getElementById("day") as HTMLInputElement).value);
    }
    processForm(value:any){
      console.log(value);
    }
   
}
